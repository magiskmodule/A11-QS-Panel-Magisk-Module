#!/sbin/busybox sh
# set perm system files

SYS=/system
APP=/system/app
PAPP=/system/product/priv-app
FRAP=/system/framework


chmod -R 644 $FRAP/framework-res.apk
chmod -R 644 $PAPP/Settings/Settings.apk
chmod -R 644 $PAPP/SystemUI/SystemUI.apk

